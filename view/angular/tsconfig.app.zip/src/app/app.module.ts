import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {HttpModule} from '@angular/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {VerifyService} from './service/app.service';
import {VerifyComponent} from '../components/verify.component';

@NgModule({
  declarations: [
    AppComponent,
    VerifyComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpModule
  ],
  providers: [VerifyService],
  bootstrap: [AppComponent],
  exports:[VerifyComponent]
})
export class AppModule { }
