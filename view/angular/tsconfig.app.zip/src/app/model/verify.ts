export class verify {
    // id: string;
    // name: string;
}